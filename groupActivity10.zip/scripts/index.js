import { getJSON, getLocation } from './utilities.js';

let baseURL =
    'https://earthquake.usgs.gov/fdsnws/event/1/query?format=geojson&starttime=2019-01-01&endtime=2019-02-02';

getLocation()
    .then (function(result) {
        const lat = result.coords.latitude;
        const long = result.coords.longitude;

        baseURL += '&latitude=' + lat + '&longitude=' + long;

    getJSON(baseURL)
        .then (function(result) {
            var ul = document.getElementById('quakeList');

            result.features.forEach(
                function(feature) {
                    var li = document.createElement('li');
                    li.textContent = 'Place: ' + feature.properties.place + ',Strength: ' + feature.properties.mag;

                    ul.appendChild(li);
                }
            )

            if (result == null) {
                document.getElementById("message").innerHTML = "There are no earthquakes where you live";
            }
        });
    });