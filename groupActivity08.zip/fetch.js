
function loadPeople(url){

if (!url) {
  url = 'https://swapi.co/api/people/';
}

let table = document.querySelector('table');

fetch(url)
  .then(
    (response) => {
      response.json()
      
      .then(
        (people) => {                //<----these are variables that can be called anything
          people.results.forEach(   //<----Iterate through each array in the "people" variable and store into "results"
            (person) => {

              let row = document.createElement('tr');

              let name = document.createElement('td');
              name.textContent = person.name;

              let birth_year = document.createElement('td');
              birth_year.textContent = person.birth_year;           

              row.appendChild(name);
              row.appendChild(birth_year);

              table.appendChild(row);  //<----This is where you append the row in the table            
            }
           );
          //work on buttons here
          console.log(people.next);


          if (people.previous == null) {
            document.querySelector('#prev').setAttribute('disabled', 'disabled');
          }
          else {
            document.getElementById("#prev").addEventListener("click", loadPeople(people.previous));
          }

          if (people.next == null) {
            document.querySelector('#next').setAttribute('disabled', 'disabled');
          }
          else {
            document.getElementById("#next").addEventListener("click", loadPeople(people.next));
          }

        }
      )

    }
  )
}